package pro03;


	class Test4 implements WithPrivate {
		void test() {
			int x = getData();
			System.out.println("x:" + x);
}
	}